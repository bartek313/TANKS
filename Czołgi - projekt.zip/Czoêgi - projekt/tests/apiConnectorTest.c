#include "../apiConnector.c"
#include "headerFiles/apiConnectorTest.h"

void testApi(){
wykonajRequest("http://edi.iem.pw.edu.pl:30000/worlds/api/v1/worlds/info/qwerty_31");
}
