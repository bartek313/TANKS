#include "../mapGenerator.c"
#include "headerFiles/mapGeneratorTest.h"

void testZapisuMapy()
{
    inicjujMape("mapa");
    zapiszMape();
}
