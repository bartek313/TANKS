#include "../algorithm.c"
#include "headerFiles/algorithmTest.h"

void testAlgorytmu()
{
    rozpocznijAutomatyczneOdkrywanie("qwerty_31");
}
