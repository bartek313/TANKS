void testZapisuMapy();
