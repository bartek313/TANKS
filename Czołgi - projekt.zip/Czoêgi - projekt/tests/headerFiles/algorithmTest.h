void testAlgorytmu();
