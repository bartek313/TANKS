#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>
#include <cjson/cJSON.h>

int choice;

int main(int argc, char** argv);
void manualSteering();
void automaticSteering();
