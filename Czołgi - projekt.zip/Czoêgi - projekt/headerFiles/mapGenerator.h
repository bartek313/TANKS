#include "jsonConverter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <png.h>

//#define infoLink "http://edi.iem.pw.edu.pl:30000/worlds/api/v1/worlds/info/"

struct Map {
   int dx;// = 20;			//delty
   int dy;// = 20;

   int dimX;// = 50;			//wymiary macierzy
   int dimY;// = 50;

   char  *name;
   int   width;
   int   length;
   int   currentX;
   int   currentY;
   char  currentField;
   char  currentDirection;
   char* fields;
};  

void zapiszMape(char* nazwaPliku);
void inicjujMape(char* nazwa);
void updateMap(char* json);
void wyczyscMape();
void zwiekszRozmiarMapy(int sizeX, int sizeY);
void wypiszMape();

char* dajInfoLink();
char* dajExploreLink();
char* dajMoveLink();
char* dajLeftLink();
char* dajRightLink();
char* dajResetLink();

int dajSzerokoscMapy();
int dajWysokoscMapy();
char* dajAktualnaMape();
