#include "apiConnector.h"
#include "mapGenerator.h"
#include "jsonConverter.h"

void rozpocznijAutomatyczneOdkrywanie(char *swiat);
void wykonajRuchy();
