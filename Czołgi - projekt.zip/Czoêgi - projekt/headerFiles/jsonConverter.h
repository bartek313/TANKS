#include <cjson/cJSON.h>
#include <stdio.h>

int  current_x;
int  current_y;
char direction;
char field_type;

void jsonParserPayload(char *json_string);
int getCurrentX();
int getCurrentY();
char getDirection();
char getFieldType();
