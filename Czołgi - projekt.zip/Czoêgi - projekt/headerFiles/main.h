#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>
#include "apiConnector.h"
#include "jsonConverter.h"
#include "algorithm.h"
#include"pngGenerator.h"

int wybor;
char swiat[100];

int main(int argc, char** argv);
void sterowanieReczne();
void sterowanieAutomatyczne();
void wyborTrybuPracy();
void generujPngMapy(char* nazwaPliku);
